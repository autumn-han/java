public class Basic {
    public static void main(String[] args) {
        System.out.println("My name is Autumn");
        System.out.println("I am 28 years old");
        System.out.println("I am originally from Appleton, WI");
    }
}