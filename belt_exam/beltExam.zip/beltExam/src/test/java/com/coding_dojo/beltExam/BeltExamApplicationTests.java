package com.coding_dojo.beltExam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeltExamApplicationTests {

	@Test
	void contextLoads() {
	}

}
